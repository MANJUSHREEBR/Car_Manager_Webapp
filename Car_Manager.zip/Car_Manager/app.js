var sampleApp = angular.module('sampleApp', ['ngStorage','highcharts-ng']);
sampleApp.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
      when('/home', {
	templateUrl: 'templates/home.html',
	controller: 'homeController'
      }).
      when('/phase', {
	templateUrl: 'templates/phase.html',
	controller: 'phaseController'
      }).
            when('/detail', {
	templateUrl: 'templates/detail.html',
	controller: 'detailController'
      }).

      otherwise({
	redirectTo:'/home'
      });
}]);





