sampleApp.controller('phaseController', function($scope,$localStorage) 
{
  $scope.index=$localStorage.index;
  if($localStorage.car=="")
  {
    window.location.href="#home";
    alert("Add Car First");
  }
 $scope.allCars=[];
 $scope.myVar1 = false;
 $scope.myVar2 = false;
 $scope.myVar3 = false;
 $scope.myVar4 = false;
 $scope.index=$localStorage.index;
 if($localStorage.allCars)
 {
  $scope.allCars=$localStorage.allCars;
 }
 else
  $localStorage.allCars=[];
$scope.load=function(){
     $scope.name1=$localStorage.car[$localStorage.index].name;
      if($localStorage.car[$scope.index].phase=="phase1")
         $scope.myVar1 = true;
      if($localStorage.car[$scope.index].phase=="phase2")
        $scope.myVar2 = true;
      if($localStorage.car[$scope.index].phase=="phase3")
        $scope.myVar3 = true;
       if($localStorage.car[$scope.index].phase=="phase4")
       $scope.myVar4= true;
   }
$scope.submit1=function(){
    if(!$scope.name1 || !$scope.milage || !$scope.model)
      alert("Fill All Fields");
    else
    {
    $scope.car={name1:"",milage:"",model:"",img:"",seats:"",gears:"",color:"",details:"",months:[]}
    $scope.myVar1 = false;
    $scope.myVar2 = true;
    $scope.car.name1=$scope.name1;
    $scope.car.milage=$scope.milage;
    $scope.car.model=$scope.model;
    $localStorage.car[$scope.index].phase="phase2";
    $localStorage.allCars.push($scope.car);
                }
  }
$scope.submit2=function(){
      if(!$scope.detail1)
      alert("Fill All Fields");
       else
       {
 
       var file    = document.querySelector('#files').files[0];
       var reader  = new FileReader();
       reader.onloadend = function () {
       var src=reader.result;
       $localStorage.allCars[$scope.index].img=src;
       $localStorage.car[$scope.index].phase="phase3";        
        }
        if (file) {
          reader.readAsDataURL(file); 
          $scope.myVar2 = false;
          $scope.myVar3 = true;
          $localStorage.allCars[$scope.index].details=$scope.detail1; 
        }  
    else{
    alert("Upload Car Image");
        }

        }
      }
$scope.submit3=function(){
  if(!$scope.seats || !$scope.gears || !$scope.color)
  alert("Fill All Fields");
  else{
  $scope.myVar3 = false;
  $scope.myVar4= true;
  $localStorage.allCars[$scope.index].seats=$scope.seats;
  $localStorage.allCars[$scope.index].gears=$scope.gears;
  $localStorage.allCars[$scope.index].color=$scope.color;
  $localStorage.car[$scope.index].phase="phase4";  
}
  }

$scope.submit4=function(){
   if(!$scope.jan || !$scope.apr || !$scope.july || !$scope.oct)
      alert("Fill All Fields");
    else{

    window.location.href="#detail";
  $scope.myVar4 = !$scope.myVar4;
  $localStorage.car[$scope.index].phase="Completed";
  $localStorage.allCars[$scope.index].months.push($scope.jan);
  $localStorage.allCars[$scope.index].months.push($scope.apr);
  $localStorage.allCars[$scope.index].months.push($scope.july);
  $localStorage.allCars[$scope.index].months.push($scope.oct); 
    }

        }

 
});


