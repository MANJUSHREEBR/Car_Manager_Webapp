sampleApp.controller('detailController', function($scope,$localStorage) {
if($localStorage.car=="")
  {
    alert("Add Car First");
    window.location.href="#home";
  }
  //Highchart starts here
$scope.highchartsNG = {
        options: {
            chart: {
                type: 'line'
            }
        },
       
      
        title: {
            text: 'Monthly Saled Car Number',
            x: -20 //center
        },
        
        xAxis: {
           
            categories: ['Jan', 'Apr', 'Jul', 'Oct']
        },
          yAxis: {
            title: {
                text: 'SaleNumber'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
      
            legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle',
            borderWidth: 0,
          
            
             },
        series: [],
           
    }
//Highchart ends here
            
$scope.allCars=$localStorage.allCars;  
$scope.selectCar="selectCar";
$scope.carSelected="selectCar";
$scope.selectPhase="selectphase";
$scope.phases=$scope.selectPhase;


$scope.showDetails=function()
  {
            $scope.value4=0;
            $scope.value1=0;
            $scope.value2=0;
             $scope.value3=0;
           
for(var i=0;i<$localStorage.allCars.length;i++)
   {
               
  if($scope.carSelected==$localStorage.allCars[i].name1)
      { 
        if($scope.phases=="Phase1")
        {
          $scope.value1=1;
          $scope.name1=$localStorage.allCars[i].name1;
        $scope.milage=$localStorage.allCars[i].milage;
        $scope.model=$localStorage.allCars[i].model;
        }
        if($scope.phases=="Phase2")
        {
          $scope.value2=1;
          $scope.details=$localStorage.allCars[i].details; 
        $scope.img=$localStorage.allCars[i].img;
        }
        if($scope.phases=="Phase3")
        {

          $scope.value3=1;
           $scope.seats=$localStorage.allCars[i].seats; 
        $scope.gears=$localStorage.allCars[i].gears;
        $scope.color=$localStorage.allCars[i].color;
        }
       if($scope.phases=="Phase4")
        {
          $scope.value4=1;
           var y1=parseFloat($localStorage.allCars[i].months[0]);
           var y2=parseFloat($localStorage.allCars[i].months[1]);
           var y3=parseFloat($localStorage.allCars[i].months[2]);
           var y4=parseFloat($localStorage.allCars[i].months[3]);
             
              var rnd=[];
              $scope.highchartsNG.series=[];
              rnd.push(y1,y2,y3,y4);
              $scope.highchartsNG.series.push({
            data: rnd ,
            name:$scope.carSelected
         
            })
           
        } 
         
        }
      
      
    }


}
  
  });
    

                 

  
  


  
