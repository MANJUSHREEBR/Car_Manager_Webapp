sampleApp.controller('homeController', function($scope,$localStorage) {
  //localStorage.clear();
$scope.details=$localStorage.allCars;
$scope.names=[];
if($localStorage.car)
{
    $scope.names=$localStorage.car;
}
else
$localStorage.car=[];
$scope.value=1;
$scope.load=function(){
  $scope.names=$localStorage.car;   
}
$scope.addStore=function() {
if(!$scope.enteredName)
alert("Type Car Name")
else
{
$scope.name_phase={name:"",phase:""};
$scope.name_phase.name=$scope.enteredName;
$scope.name_phase.phase="phase1";
$scope.names.push($scope.name_phase);
$localStorage.car=$scope.names;
$scope.enteredName="";
}
}
$scope.phases=function(index){
$localStorage.index=index;
if($localStorage.car[index].phase=="Completed") 
window.location.href="#detail";   
else{
    window.location.href="#phase";
    }
   }
$scope.searchFilter = function (details) {
    var keyword = new RegExp($scope.searchName, 'i');
    return !$scope.searchName || keyword.test(details.name1);
 };
 $scope.changeValue= function(){
if($scope.searchName!="")
$scope.value=0;
else
$scope.value=1;



};             
              
});
 